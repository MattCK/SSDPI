<?php return array(
    'includes' => array('_aws'),
    'services' => array(
        'default_settings' => array(
            'params' => array(
                'key'    => 'AKIAILNZLWH7FTS2CGKA',
                'secret' => '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',
                'region' => 'us-east-1'
            )
        )
    )
);