<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class UnknownBaseRate extends \Google\AdsApi\Dfp\v201702\BaseRate
{

    /**
     * @param int $rateCardId
     * @param int $id
     */
    public function __construct($rateCardId = null, $id = null)
    {
      parent::__construct($rateCardId, $id);
    }

}
