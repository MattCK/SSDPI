<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ProductTemplateActionErrorReason
{
    const NOT_APPLICABLE = 'NOT_APPLICABLE';
    const UNKNOWN = 'UNKNOWN';


}
