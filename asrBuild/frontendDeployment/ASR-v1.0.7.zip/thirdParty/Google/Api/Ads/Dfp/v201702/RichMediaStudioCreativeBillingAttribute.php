<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class RichMediaStudioCreativeBillingAttribute
{
    const IN_PAGE = 'IN_PAGE';
    const FLOATING_EXPANDING = 'FLOATING_EXPANDING';
    const VIDEO = 'VIDEO';
    const FLASH_IN_FLASH = 'FLASH_IN_FLASH';


}
