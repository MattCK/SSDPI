<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class GeographyPremiumFeature extends \Google\AdsApi\Dfp\v201702\PremiumFeature
{

    
    public function __construct()
    {
    
    }

}
