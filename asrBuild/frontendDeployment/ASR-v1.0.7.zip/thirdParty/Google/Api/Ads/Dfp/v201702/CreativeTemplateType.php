<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CreativeTemplateType
{
    const SYSTEM_DEFINED = 'SYSTEM_DEFINED';
    const USER_DEFINED = 'USER_DEFINED';


}
