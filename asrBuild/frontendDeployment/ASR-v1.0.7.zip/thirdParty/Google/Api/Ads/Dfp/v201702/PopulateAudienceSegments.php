<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class PopulateAudienceSegments extends \Google\AdsApi\Dfp\v201702\AudienceSegmentAction
{

    
    public function __construct()
    {
    
    }

}
