<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateProductPackages extends \Google\AdsApi\Dfp\v201702\ProductPackageAction
{

    
    public function __construct()
    {
    
    }

}
