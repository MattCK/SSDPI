<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class LineItemDiscountType
{
    const ABSOLUTE_VALUE = 'ABSOLUTE_VALUE';
    const PERCENTAGE = 'PERCENTAGE';


}
