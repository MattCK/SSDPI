<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class PricingMethod
{
    const SUM = 'SUM';
    const HIGHEST = 'HIGHEST';
    const ANY_VALUE = 'ANY_VALUE';
    const UNKNOWN = 'UNKNOWN';


}
