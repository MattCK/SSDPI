<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ServerErrorReason
{
    const SERVER_ERROR = 'SERVER_ERROR';
    const SERVER_BUSY = 'SERVER_BUSY';
    const UNKNOWN = 'UNKNOWN';


}
