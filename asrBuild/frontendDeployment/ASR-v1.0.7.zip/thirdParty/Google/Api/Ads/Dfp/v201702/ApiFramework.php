<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ApiFramework
{
    const NONE = 'NONE';
    const CLICKTAG = 'CLICKTAG';
    const VPAID = 'VPAID';


}
