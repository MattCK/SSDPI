<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeleteExchangeRates extends \Google\AdsApi\Dfp\v201702\ExchangeRateAction
{

    
    public function __construct()
    {
    
    }

}
