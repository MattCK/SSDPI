<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CustomFieldDataType
{
    const STRING = 'STRING';
    const NUMBER = 'NUMBER';
    const TOGGLE = 'TOGGLE';
    const DROP_DOWN = 'DROP_DOWN';
    const UNKNOWN = 'UNKNOWN';


}
