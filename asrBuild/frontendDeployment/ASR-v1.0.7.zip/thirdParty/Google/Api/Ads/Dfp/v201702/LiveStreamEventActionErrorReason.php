<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class LiveStreamEventActionErrorReason
{
    const INVALID_STATUS_TRANSITION = 'INVALID_STATUS_TRANSITION';
    const IS_ARCHIVED = 'IS_ARCHIVED';
    const UNKNOWN = 'UNKNOWN';


}
