<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class PauseOrders extends \Google\AdsApi\Dfp\v201702\OrderAction
{

    
    public function __construct()
    {
    
    }

}
