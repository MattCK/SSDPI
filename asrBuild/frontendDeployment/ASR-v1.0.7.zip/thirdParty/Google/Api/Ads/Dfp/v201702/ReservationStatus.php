<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ReservationStatus
{
    const RESERVED = 'RESERVED';
    const NOT_RESERVED = 'NOT_RESERVED';
    const RELEASED = 'RELEASED';
    const CHECK_LINE_ITEM_RESERVATION_STATUS = 'CHECK_LINE_ITEM_RESERVATION_STATUS';
    const UNKNOWN = 'UNKNOWN';


}
