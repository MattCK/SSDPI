<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BaseRateActionErrorReason
{
    const PRODUCT_BASE_RATE_EXISTS = 'PRODUCT_BASE_RATE_EXISTS';
    const UNKNOWN = 'UNKNOWN';


}
