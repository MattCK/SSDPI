<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class WorkflowEvaluationStatus
{
    const PENDING = 'PENDING';
    const TRIGGERED = 'TRIGGERED';
    const NOT_TRIGGERED = 'NOT_TRIGGERED';
    const CANCELLED = 'CANCELLED';
    const UNKNOWN = 'UNKNOWN';


}
