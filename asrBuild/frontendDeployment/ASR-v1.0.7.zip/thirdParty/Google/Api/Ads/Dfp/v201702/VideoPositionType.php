<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class VideoPositionType
{
    const PREROLL = 'PREROLL';
    const MIDROLL = 'MIDROLL';
    const POSTROLL = 'POSTROLL';


}
