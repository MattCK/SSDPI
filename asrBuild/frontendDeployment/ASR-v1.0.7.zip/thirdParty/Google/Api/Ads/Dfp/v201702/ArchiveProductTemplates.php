<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ArchiveProductTemplates extends \Google\AdsApi\Dfp\v201702\ProductTemplateAction
{

    
    public function __construct()
    {
    
    }

}
