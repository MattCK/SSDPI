<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class SslScanResult
{
    const UNKNOWN = 'UNKNOWN';
    const UNSCANNED = 'UNSCANNED';
    const SCANNED_SSL = 'SCANNED_SSL';
    const SCANNED_NON_SSL = 'SCANNED_NON_SSL';


}
