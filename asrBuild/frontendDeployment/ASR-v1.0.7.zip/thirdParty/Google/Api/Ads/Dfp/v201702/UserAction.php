<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
abstract class UserAction
{

    
    public function __construct()
    {
    
    }

}
