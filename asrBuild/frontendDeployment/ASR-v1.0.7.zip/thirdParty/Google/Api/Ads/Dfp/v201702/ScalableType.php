<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ScalableType
{
    const UNKNOWN = 'UNKNOWN';
    const NOT_SCALABLE = 'NOT_SCALABLE';
    const RATIO_SCALABLE = 'RATIO_SCALABLE';
    const STRETCH_SCALABLE = 'STRETCH_SCALABLE';


}
