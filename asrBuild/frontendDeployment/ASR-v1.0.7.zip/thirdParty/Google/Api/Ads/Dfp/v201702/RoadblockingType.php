<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class RoadblockingType
{
    const ONLY_ONE = 'ONLY_ONE';
    const ONE_OR_MORE = 'ONE_OR_MORE';
    const AS_MANY_AS_POSSIBLE = 'AS_MANY_AS_POSSIBLE';
    const ALL_ROADBLOCK = 'ALL_ROADBLOCK';
    const CREATIVE_SET = 'CREATIVE_SET';


}
