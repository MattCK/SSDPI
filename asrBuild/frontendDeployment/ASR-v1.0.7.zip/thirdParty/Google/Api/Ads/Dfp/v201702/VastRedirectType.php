<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class VastRedirectType
{
    const LINEAR = 'LINEAR';
    const NON_LINEAR = 'NON_LINEAR';
    const LINEAR_AND_NON_LINEAR = 'LINEAR_AND_NON_LINEAR';


}
