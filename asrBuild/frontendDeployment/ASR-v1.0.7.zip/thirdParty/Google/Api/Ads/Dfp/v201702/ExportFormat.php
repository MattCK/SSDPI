<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ExportFormat
{
    const TSV = 'TSV';
    const TSV_EXCEL = 'TSV_EXCEL';
    const CSV_DUMP = 'CSV_DUMP';
    const XML = 'XML';
    const XLSX = 'XLSX';


}
