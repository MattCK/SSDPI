<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class SwiffyConversionErrorReason
{
    const SERVER_ERROR = 'SERVER_ERROR';
    const INVALID_FLASH_FILE = 'INVALID_FLASH_FILE';
    const UNSUPPORTED_FLASH = 'UNSUPPORTED_FLASH';
    const UNKNOWN = 'UNKNOWN';


}
