<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ContentPartnerErrorReason
{
    const INVALID_PARTNER_TYPE = 'INVALID_PARTNER_TYPE';
    const NO_PARTNER_CATCH_ALL = 'NO_PARTNER_CATCH_ALL';
    const UNKNOWN = 'UNKNOWN';


}
