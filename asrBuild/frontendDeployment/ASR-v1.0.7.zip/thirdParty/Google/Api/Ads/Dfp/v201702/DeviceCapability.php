<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeviceCapability extends \Google\AdsApi\Dfp\v201702\Technology
{

    /**
     * @param int $id
     * @param string $name
     */
    public function __construct($id = null, $name = null)
    {
      parent::__construct($id, $name);
    }

}
