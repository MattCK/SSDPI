<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ProductPackageRateCardAssociationErrorReason
{
    const INVALID_RATE_CARD_ID = 'INVALID_RATE_CARD_ID';
    const INVALID_PRODUCT_PACKAGE_ID = 'INVALID_PRODUCT_PACKAGE_ID';
    const UNKNOWN = 'UNKNOWN';


}
