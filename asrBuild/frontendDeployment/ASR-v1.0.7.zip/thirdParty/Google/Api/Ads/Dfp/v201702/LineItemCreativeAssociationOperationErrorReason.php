<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class LineItemCreativeAssociationOperationErrorReason
{
    const NOT_ALLOWED = 'NOT_ALLOWED';
    const NOT_APPLICABLE = 'NOT_APPLICABLE';
    const CANNOT_ACTIVATE_INVALID_CREATIVE = 'CANNOT_ACTIVATE_INVALID_CREATIVE';
    const UNKNOWN = 'UNKNOWN';


}
