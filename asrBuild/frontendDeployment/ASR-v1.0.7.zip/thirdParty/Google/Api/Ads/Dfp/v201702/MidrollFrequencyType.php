<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class MidrollFrequencyType
{
    const NONE = 'NONE';
    const EVERY_N_SECONDS = 'EVERY_N_SECONDS';
    const FIXED_TIME = 'FIXED_TIME';
    const EVERY_N_CUEPOINTS = 'EVERY_N_CUEPOINTS';
    const FIXED_CUE_POINTS = 'FIXED_CUE_POINTS';
    const UNKNOWN = 'UNKNOWN';


}
