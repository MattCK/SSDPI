<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ArchiveStatus
{
    const ARCHIVED = 'ARCHIVED';
    const NOT_ARCHIVED = 'NOT_ARCHIVED';
    const PRODUCT_TEMPLATE_ARCHIVED = 'PRODUCT_TEMPLATE_ARCHIVED';
    const UNKNOWN = 'UNKNOWN';


}
