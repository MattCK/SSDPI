<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ProductStatus
{
    const ACTIVE = 'ACTIVE';
    const INACTIVE = 'INACTIVE';
    const ARCHIVED = 'ARCHIVED';
    const UNKNOWN = 'UNKNOWN';


}
