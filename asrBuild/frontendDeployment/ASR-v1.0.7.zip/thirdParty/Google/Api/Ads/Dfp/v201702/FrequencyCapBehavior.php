<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class FrequencyCapBehavior
{
    const TURN_ON = 'TURN_ON';
    const TURN_OFF = 'TURN_OFF';
    const DEFER = 'DEFER';
    const UNKNOWN = 'UNKNOWN';


}
