<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ReconciliationReportStatus
{
    const DRAFT = 'DRAFT';
    const RECONCILED = 'RECONCILED';
    const REVERTED = 'REVERTED';
    const PENDING = 'PENDING';
    const UNKNOWN = 'UNKNOWN';


}
