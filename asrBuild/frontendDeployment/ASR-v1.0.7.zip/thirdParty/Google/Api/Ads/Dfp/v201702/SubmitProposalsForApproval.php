<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class SubmitProposalsForApproval extends \Google\AdsApi\Dfp\v201702\ProposalAction
{

    
    public function __construct()
    {
    
    }

}
