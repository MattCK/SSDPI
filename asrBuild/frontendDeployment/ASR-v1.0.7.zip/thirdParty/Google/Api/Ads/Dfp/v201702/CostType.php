<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CostType
{
    const CPA = 'CPA';
    const CPC = 'CPC';
    const CPD = 'CPD';
    const CPM = 'CPM';
    const VCPM = 'VCPM';
    const UNKNOWN = 'UNKNOWN';


}
