<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class PauseLiveStreamEvents extends \Google\AdsApi\Dfp\v201702\LiveStreamEventAction
{

    
    public function __construct()
    {
    
    }

}
