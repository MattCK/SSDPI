<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ProductPackageActionErrorReason
{
    const ACTIVATE_WITH_INACTIVE_MANDATORY_PRODUCT = 'ACTIVATE_WITH_INACTIVE_MANDATORY_PRODUCT';
    const NOT_APPLICABLE = 'NOT_APPLICABLE';
    const UNKNOWN = 'UNKNOWN';


}
