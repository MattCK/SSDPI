<?php

namespace Google\AdsApi\Dfp\v201702;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ProductPackageItemErrorReason
{
    const ARCHIVED_PRODUCT_NOT_ALLOWED = 'ARCHIVED_PRODUCT_NOT_ALLOWED';
    const INACTIVE_MANDATORY_PRODUCT_NOT_ALLOWED = 'INACTIVE_MANDATORY_PRODUCT_NOT_ALLOWED';
    const UNKNOWN = 'UNKNOWN';


}
